package com.bizoss.trade.distribution.dao;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import com.bizoss.trade.base.BaseDaoImpl;
import com.bizoss.trade.distribution.bean.Distribution;
import com.ibatis.sqlmap.client.SqlMapClient;
@Repository
public class DistributionDaoImpl extends BaseDaoImpl<Distribution>{
	
}
