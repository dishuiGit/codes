package com.bizoss.trade.distribution.controler;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.bizoss.trade.distribution.bean.Distribution;

@Controller
@RequestMapping("/dis")
public class DistributionController {
	private static Logger logger = Logger.getLogger(DistributionController.class);
	
	@RequestMapping("/test")
	public String disTest(Distribution db){
		logger.info("test");
		return "test";
	}
}
