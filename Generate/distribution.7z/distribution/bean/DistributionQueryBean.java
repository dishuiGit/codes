package com.bizoss.trade.distribution.bean;

import com.bizoss.trade.base.BaseQueryBean;


public class DistributionQueryBean implements BaseQueryBean {
	
}
