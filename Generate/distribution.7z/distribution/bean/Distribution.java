package com.bizoss.trade.distribution.bean;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.google.common.base.MoreObjects;

@Component
public class Distribution {
	@Value("xx2331")
	private String id;
	@Value("23")
	private Integer age;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public String toString() {
		return MoreObjects.toStringHelper(this).add("id", id).add("age", age)
				.toString();
	}
	
}
