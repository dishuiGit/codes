package com.bizoss.trade.distribution.service;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.bizoss.trade.base.BaseServiceWarper;
import com.bizoss.trade.distribution.bean.Distribution;
import com.bizoss.trade.distribution.dao.DistributionDaoImpl;

@Service
public class DistributionSeriviceImpl extends BaseServiceWarper<Distribution>{
	
	@Resource
	private DistributionDaoImpl distributionDaoImpl;
	
	public void save(Distribution t) {
		distributionDaoImpl.save(t);
	}

	
}
